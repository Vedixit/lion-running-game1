let score = 0;
const lion = document.getElementById("lion");
const scoreDisplay = document.getElementById("score");

document.addEventListener("keydown", function (event) {
    if (event.code === "Space") {
        if (!lion.classList.contains("jump")) {
            lion.classList.add("jump");
            setTimeout(() => lion.classList.remove("jump"), 600);
        }
    }
});

setInterval(() => {
    score++;
    scoreDisplay.textContent = "Score: " + score;
}, 1000);